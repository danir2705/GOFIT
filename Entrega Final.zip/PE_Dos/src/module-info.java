module PE_Dos {
	requires javafx.controls;
	
	opens Logica to javafx.graphics, javafx.fxml;
}
