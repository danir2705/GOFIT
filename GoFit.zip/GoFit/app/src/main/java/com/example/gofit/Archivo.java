package com.example.gofit;

import android.os.Environment;
import android.os.Parcelable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatCallback;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public interface Archivo {
    File archivoUsuarios = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            "Usuarios.txt");
}
