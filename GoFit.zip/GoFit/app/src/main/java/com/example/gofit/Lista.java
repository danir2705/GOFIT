package com.example.gofit;

public class Lista
{
    static class Nodo<T>
    {
        protected T dato;
        int posicion;
        Nodo<T> siguiente;
        Nodo<T> anterior;

        Nodo(T dato)
        {
            this.dato=dato;
            this.siguiente = null;
            this.anterior = null;
        }
    }

    protected Nodo cabeza;
    protected Nodo cola;
    int tamaño = 0;

    public int size()
    {
        return this.tamaño;
    }

    public Object getCola()
    {
        return this.cola.dato;
    }
    public Object getCabeza()
    {
        return this.cabeza.dato;
    }
}