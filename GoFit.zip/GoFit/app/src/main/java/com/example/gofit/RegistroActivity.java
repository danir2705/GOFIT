package com.example.gofit;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class RegistroActivity extends AppCompatActivity implements Archivo{
    Button registrarse;
    Spinner spinner_genero;
    EditText nombre_nuevo,contraseña_nuevo,peso_nuevo,edad_nuevo;
    ListaEnlazada<Usuario> ListaUsuarios;
    String nombre,contraseña,lista;
    int edad,peso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        ListaUsuarios = new ListaEnlazada<Usuario>();
        registrarse = findViewById(R.id.boton_registrarse);
        spinner_genero = findViewById(R.id.spinner_generos);
        nombre_nuevo = findViewById(R.id.nombre);
        contraseña_nuevo = findViewById(R.id.contraseña);
        peso_nuevo = findViewById(R.id.peso);
        edad_nuevo = findViewById(R.id.edad);


        cargar();


        ArrayAdapter<CharSequence>  adapter = ArrayAdapter.createFromResource(this,R.array.generos, android.R.layout.simple_spinner_item);
        spinner_genero.setAdapter(adapter);

    registrarse.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View view) {
            nombre = nombre_nuevo.getText().toString();
            edad = Integer.valueOf(edad_nuevo.getText().toString());
            peso = Integer.valueOf(peso_nuevo.getText().toString());
            contraseña = contraseña_nuevo.getText().toString();

              if (ListaUsuarios.existeUsuario(nombre) != null) {
              Toast.makeText(getApplicationContext(), "El usuario ya existe", Toast.LENGTH_SHORT)
                  .show();
            } else if (edad < 14 || edad > 100) {
              Toast.makeText(
                      getApplicationContext(),
                      "Por favor escriba su edad dentro del rango establecido",
                      Toast.LENGTH_LONG)
                  .show();
            } else if (peso < 40 || peso > 130) {
              Toast.makeText(
                      getApplicationContext(),
                      "Por favor escriba su peso dentro del rango establecido",
                      Toast.LENGTH_LONG)
                  .show();
            } else {
                Intent intent = new Intent(RegistroActivity.this, MainActivity.class);

                  try {
                      escribir();
                  } catch (IOException e) {
                      e.printStackTrace();
                  }
                Toast.makeText(
                        getApplicationContext(), "El registro ha sido exitoso", Toast.LENGTH_SHORT)
                    .show();

                startActivity(intent);
                  try {
                      escribir();
                  } catch (IOException e) {
                      e.printStackTrace();
                  }
                  finish();
              }
          }
        });
    }

    protected void cargar() {
        Scanner lectorArchivo = null;
        try {
            lectorArchivo = new Scanner(archivoUsuarios);

        while(lectorArchivo.hasNextLine())
        {

            String nombreUsuario = "";
            int edadUsuario = 0;
            int pesoUsuario = 0;
            String generoUsuario = "";
            String claveUsuario = "";
            String entrada = lectorArchivo.nextLine();
            String datoActual = "";
            int contador = 0;
            for(int i = 0;i<entrada.length();i++)
            {
                if(entrada.charAt(i)!=',')
                {
                    datoActual+=entrada.charAt(i);
                }
                else
                {
                    switch(contador)
                    {
                        case 0:
                            nombreUsuario = datoActual;
                            datoActual = "";
                            contador+=1;
                            break;
                        case 1:
                            edadUsuario = Integer.parseInt(datoActual);
                            datoActual = "";
                            contador+=1;
                            break;
                        case 2:
                            pesoUsuario = Integer.parseInt(datoActual);
                            datoActual = "";
                            contador+=1;
                            break;
                        case 3:
                            generoUsuario = datoActual;
                            datoActual = "";
                            contador+=1;
                            break;
                        case 4:
                            claveUsuario = datoActual;
                            datoActual = "";
                            contador+=1;
                            break;
                    }
                }
            }
            lista+=nombreUsuario +","+ edadUsuario +","+ pesoUsuario +","+ generoUsuario +","+ claveUsuario +","+"\n";
            ListaUsuarios.addUsuarioUnicamenteALista(nombreUsuario, edadUsuario, pesoUsuario, generoUsuario, claveUsuario);
        }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void escribir() throws IOException {
        FileWriter fichero = null;
        PrintWriter pw = null;
        fichero = new FileWriter(archivoUsuarios);
        pw = new PrintWriter(fichero);

        pw.println(lista+nombre+","+edad+","+peso+","+spinner_genero.getSelectedItem().toString()+","+contraseña+",");

        pw.flush();

        pw.close();
        fichero.close();

    }

}