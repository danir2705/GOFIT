package com.example.gofit;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.gofit.databinding.ActivityMainMenuBinding;
import com.example.gofit.ui.gallery.GalleryFragment;
import com.example.gofit.ui.home.HomeFragment;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

public class MainMenu extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainMenuBinding binding;
    private ListaEnlazada<Usuario> ListaUsuarios;
    private String usuario;
    ListaEnlazada<Rutinas> Rutinas = new ListaEnlazada<Rutinas>();
    Ejercicios bicepCurl = new Ejercicios("Bicep Curl","Lleva la mancuerna en posicion neurtral hasta tu hombro","2","8-12");
    Ejercicios bicepHammer = new Ejercicios("Hammer Curl","Con tu pulgar mirando hacia arriba, realiza una curl del bicep","3","8-12");
    Ejercicios flexionBicep = new Ejercicios("Flexiones Inversas","Realiza una flexión o lagartija con tus muñecas apuntando hacia afuera","8","6-8");
    Ejercicios bicepInverso = new Ejercicios("Curl Inverso","Con la palma de tu mano mirando hacia abajo, realiza un curl normal","6","8-10");
    Pila<Ejercicios> pilaBicepUno = new Pila<Ejercicios>();
    Pila<Ejercicios> pilaBicepDos = new Pila<Ejercicios>();
    Cola<Ejercicios> colaBicepUno = new Cola<Ejercicios>();
    Rutinas rutinaBicep = new Rutinas("4",pilaBicepUno,pilaBicepDos,colaBicepUno);
    FrameLayout cont;

    ImageButton brazo,pierna,abdomen,pechoespalda;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainMenuBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMainMenu.toolbar);
        binding.appBarMainMenu.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main_menu);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        pilaBicepUno.push(bicepCurl);
        pilaBicepUno.push(bicepHammer);
        pilaBicepUno.push(flexionBicep);
        pilaBicepUno.push(bicepInverso);

        recibir();

        brazo = findViewById(R.id.brazo);
        pierna = findViewById(R.id.pierna);
        pechoespalda = findViewById(R.id.pech_y_esp);
        abdomen =findViewById(R.id.abdomen);
        cont = findViewById(R.id.container);

    brazo.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {

              cont.setVisibility(View.VISIBLE);
            getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.container, new RutinaFragment())
                    .commit();
            System.out.println("Holaaaaaaaaaaaaaa");
          }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main_menu);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    public void recibir(){

        Bundle extras = getIntent().getExtras();

        usuario = extras.getString("usuario");

        brazo = findViewById(R.id.brazo);
        pierna = findViewById(R.id.pierna);
        abdomen = findViewById(R.id.abdomen);
        pechoespalda= findViewById(R.id.pech_y_esp);

    }

    public void cargar(){

        String nombreUsuario = "";
        int edadUsuario = 0;
        int pesoUsuario = 0;
        String generoUsuario = "";
        String claveUsuario = "";
        String entrada = usuario;
        String datoActual = "";
        int contador = 0;
        for(int i = 0;i<entrada.length();i++)
        {
            if(entrada.charAt(i)!=',')
            {
                datoActual+=entrada.charAt(i);
            }
            else
            {
                switch(contador)
                {
                    case 0:
                        nombreUsuario = datoActual;
                        datoActual = "";
                        contador+=1;
                        break;
                    case 1:
                        edadUsuario = Integer.parseInt(datoActual);
                        datoActual = "";
                        contador+=1;
                        break;
                    case 2:
                        pesoUsuario = Integer.parseInt(datoActual);
                        datoActual = "";
                        contador+=1;
                        break;
                    case 3:
                        generoUsuario = datoActual;
                        datoActual = "";
                        contador+=1;
                        break;
                    case 4:
                        claveUsuario = datoActual;
                        datoActual = "";
                        contador+=1;
                        break;
                }
            }
        }
        ListaUsuarios.addUsuarioUnicamenteALista(nombreUsuario, edadUsuario, pesoUsuario, generoUsuario, claveUsuario);


    }
}