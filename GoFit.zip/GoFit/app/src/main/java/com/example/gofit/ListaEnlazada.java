package com.example.gofit;

import android.content.Context;
import android.os.Environment;
import android.os.Parcel;
import android.os.Parcelable;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.Scanner;

class ListaEnlazada<G>  implements Archivo
{
    FileWriter editorArchivo;
    protected Lista.Nodo cabeza;
    protected Lista.Nodo cola;
    int tamaño = 0;

    public int size()
    {
        return this.tamaño;
    }

    public Object getCola()
    {
        return this.cola.dato;
    }
    public Object getCabeza()
    {
        return this.cabeza.dato;
    }


    public void addUsuario(String nombreUsuario, int edad, int peso, String genero, String clave)
    {
        if(this.cabeza == null)
        {
            Usuario usuarioNuevo = new Usuario(nombreUsuario, edad, peso, genero, clave);
            this.cabeza = new Lista.Nodo<Usuario>(usuarioNuevo);
            this.cabeza.posicion = 0;
            this.tamaño = 1;
            String lista = "";
            try
            {
                Scanner lectorArchivo = new Scanner(archivoUsuarios);
                while(lectorArchivo.hasNextLine())
                {
                    lista+=lectorArchivo.nextLine();
                    lista+="\n";
                }
        System.out.println(lista);
                FileWriter editorArchivo = new FileWriter(archivoUsuarios);
                editorArchivo.write(lista+nombreUsuario+","+edad+","+peso+","+genero+","+clave+","+"\n");
                editorArchivo.close();

            }
            catch(IOException e)
            {
                System.out.println("No se pudo realizar el registro adecuadamente");
            }

        }
        else
        {
            Lista.Nodo<Usuario> actual = this.cabeza;
            while(actual.siguiente!= null)
            {
                actual = actual.siguiente;
            }
            Usuario usuarioNuevo = new Usuario(nombreUsuario, edad, peso, genero, clave);
            Lista.Nodo<Usuario> nuevoNodo = new Lista.Nodo<Usuario>(usuarioNuevo);
            actual.siguiente= nuevoNodo;
            nuevoNodo.posicion = this.tamaño;
            this.tamaño+=1;

            try
            {
                FileWriter editorArchivo = new FileWriter(archivoUsuarios);
                editorArchivo.write(nombreUsuario+","+edad+","+peso+","+genero+","+clave+","+"\n");
                editorArchivo.close();
            }
            catch(IOException e)
            {
                System.out.println("No se pudo realizar el registro");
            }
        }
    }


    public void addUsuarioUnicamenteALista(String nombreUsuario, int edad, int peso, String genero, String clave)
    {
        if(this.cabeza == null)
        {
            Usuario usuarioNuevo = new Usuario(nombreUsuario, edad, peso, genero, clave);
            this.cabeza = new Lista.Nodo<Usuario>(usuarioNuevo);
            this.cabeza.posicion = 0;
            this.tamaño= 1;
        }
        else
        {
            Lista.Nodo<Usuario> actual = this.cabeza;
            while(actual.siguiente!= null)
            {
                actual = actual.siguiente;
            }
            Usuario usuarioNuevo = new Usuario(nombreUsuario, edad, peso, genero, clave);
            Lista.Nodo<Usuario> nuevoNodo = new Lista.Nodo<Usuario>(usuarioNuevo);
            actual.siguiente= nuevoNodo;
            nuevoNodo.posicion = this.tamaño;
            this.tamaño+=1;
        }

    }
    public void addRutinas(Rutinas rutina)
    {
        if(this.cabeza == null)
        {
            Rutinas rutinaNueva = rutina;
            this.cabeza = new Lista.Nodo<Rutinas>(rutinaNueva);
            this.cabeza.posicion = 0;
            this.tamaño= 1;
        }
        else
        {
            Lista.Nodo<Rutinas> actual = this.cabeza;
            while(actual.siguiente!= null)
            {
                actual = actual.siguiente;
            }
            Rutinas rutinaNuevo = rutina;
            Lista.Nodo<Rutinas> nuevoNodo = new Lista.Nodo<Rutinas>(rutina);
            actual.siguiente= nuevoNodo;
            nuevoNodo.posicion = this.tamaño;
            this.tamaño+=1;
        }

    }

    public Object getValueAtUsuario(String nombreUsuario)
    {
        Lista.Nodo<Usuario> actual = this.cabeza;
        while(actual.dato.getNombreUsuario() != nombreUsuario )
        {
            actual=actual.siguiente;
        }
        return actual.dato.getPeso();
    }

    public Usuario existeUsuario(String nombreUsuario)
    {
        Usuario retorno = null;
        Lista.Nodo<Usuario> nodoActual = this.cabeza;
        while(nodoActual != null)
        {
            if(nodoActual.dato.getNombreUsuario().equals(nombreUsuario))
            {
                retorno = nodoActual.dato;
                break;
            }
            else
            {
                nodoActual = nodoActual.siguiente;
            }
        }

        return retorno;
    }


}
