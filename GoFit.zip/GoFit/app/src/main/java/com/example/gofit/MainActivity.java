package com.example.gofit;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;


public class MainActivity extends AppCompatActivity implements  Archivo{

    Button registro, ingreso;
    ListaEnlazada<Usuario> Usuarios = new ListaEnlazada<Usuario>();

    EditText usuario, contraseña;
    String lista;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        usuario = findViewById(R.id.usuario_is);
        contraseña = findViewById(R.id.contraseña_is);

        lista="";
        try {
            if(archivoUsuarios.createNewFile())
            {
                System.out.println("Archivo creado de forma exitosa");
            }
            else
            {
                System.out.println("El archivo ya existe");
                cargar();
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Se produjo un error al cargar los datos");
        }

        //menuPrincipal(Usuarios, rutinaBicep);

        registro = findViewById(R.id.boton_registro);
    registro.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View view) {
            Intent intent = new Intent(MainActivity.this, RegistroActivity.class);
            Scanner lectorArchivo = null;
            try {
              lectorArchivo = new Scanner(archivoUsuarios);
            } catch (FileNotFoundException e) {
              e.printStackTrace();
            }
            while (lectorArchivo.hasNextLine()) {
              lista += lectorArchivo.nextLine() + "\n";
            }

            startActivity(intent);
          }
        });

        ingreso = findViewById(R.id.boton_ingreso);
    ingreso.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            ingresoUsuario(Usuarios);

          }
        });
    }

    protected void ingresoUsuario(ListaEnlazada<Usuario> listaUsuarios) //Completo
    {
        Scanner lectorEntrada = new Scanner(System.in);

        String nombreUsuario = "Null";
        String contraseñaUsuario = "Null";
        Usuario usuarioactual;

        nombreUsuario = usuario.getText().toString();
        contraseñaUsuario = contraseña.getText().toString();
        usuarioactual = listaUsuarios.existeUsuario(nombreUsuario);

        if(listaUsuarios.existeUsuario(nombreUsuario)!=null && listaUsuarios.existeUsuario(nombreUsuario).getContraseña().equals(contraseñaUsuario)==true)
        {

            Intent intent = new Intent(MainActivity.this,MainMenu.class);
            Usuario user = listaUsuarios.existeUsuario(nombreUsuario);
            String usu = user.getNombreUsuario()+","+user.getEdad()+","+user.getPeso()+","+user.getGenero()+","+user.getContraseña()+",";
            intent.putExtra("usuario",usu);
            startActivity(intent);
            finish();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"El usuario o contraseña son incorrectos", Toast.LENGTH_SHORT).show();

        }
    }
    private void cargar(){
        try
        {
            Scanner lectorArchivo = new Scanner(archivoUsuarios);
            while(lectorArchivo.hasNextLine())
            {

                String nombreUsuario = "";
                int edadUsuario = 0;
                int pesoUsuario = 0;
                String generoUsuario = "";
                String claveUsuario = "";
                String entrada = lectorArchivo.nextLine();
                String datoActual = "";
                int contador = 0;
                for(int i = 0;i<entrada.length();i++)
                {
                    if(entrada.charAt(i)!=',')
                    {
                        datoActual+=entrada.charAt(i);
                    }
                    else
                    {
                        switch(contador)
                        {
                            case 0:
                                nombreUsuario = datoActual;
                                datoActual = "";
                                contador+=1;
                                break;
                            case 1:
                                edadUsuario = Integer.parseInt(datoActual);
                                datoActual = "";
                                contador+=1;
                                break;
                            case 2:
                                pesoUsuario = Integer.parseInt(datoActual);
                                datoActual = "";
                                contador+=1;
                                break;
                            case 3:
                                generoUsuario = datoActual;
                                datoActual = "";
                                contador+=1;
                                break;
                            case 4:
                                claveUsuario = datoActual;
                                datoActual = "";
                                contador+=1;
                                break;
                        }
                    }
                }
                Usuarios.addUsuarioUnicamenteALista(nombreUsuario, edadUsuario, pesoUsuario, generoUsuario, claveUsuario);
            }
        }

        catch(FileNotFoundException e)
        {
            System.out.println("An error occurred.");
        }
    }
}





